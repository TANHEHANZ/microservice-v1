# Details

Date : 2025-06-08 23:30:54

Directory c:\\Users\\mi\\Desktop\\PROYECTOS\\REFACTOR\\getway

Total : 22 files,  449 codes, 0 comments, 61 blanks, all 510 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [getway/Dockerfile](/getway/Dockerfile) | Docker | 19 | 0 | 9 | 28 |
| [getway/nodemon.json](/getway/nodemon.json) | JSON | 6 | 0 | 1 | 7 |
| [getway/package.json](/getway/package.json) | JSON | 39 | 0 | 1 | 40 |
| [getway/src/app.ts](/getway/src/app.ts) | TypeScript | 8 | 0 | 3 | 11 |
| [getway/src/config/config.ts](/getway/src/config/config.ts) | TypeScript | 40 | 0 | 5 | 45 |
| [getway/src/config/constants.ts](/getway/src/config/constants.ts) | TypeScript | 2 | 0 | 1 | 3 |
| [getway/src/config/logger.ts](/getway/src/config/logger.ts) | TypeScript | 63 | 0 | 3 | 66 |
| [getway/src/enum/redirect.enum.ts](/getway/src/enum/redirect.enum.ts) | TypeScript | 5 | 0 | 1 | 6 |
| [getway/src/enum/services.enum.ts](/getway/src/enum/services.enum.ts) | TypeScript | 5 | 0 | 1 | 6 |
| [getway/src/errors/AuthenticationError.ts](/getway/src/errors/AuthenticationError.ts) | TypeScript | 2 | 0 | 2 | 4 |
| [getway/src/errors/EntityNotFoundError.ts](/getway/src/errors/EntityNotFoundError.ts) | TypeScript | 3 | 0 | 2 | 5 |
| [getway/src/errors/customError.ts](/getway/src/errors/customError.ts) | TypeScript | 20 | 0 | 3 | 23 |
| [getway/src/errors/types.d.ts](/getway/src/errors/types.d.ts) | TypeScript | 1 | 0 | 1 | 2 |
| [getway/src/middlewares/error-handler.ts](/getway/src/middlewares/error-handler.ts) | TypeScript | 48 | 0 | 5 | 53 |
| [getway/src/middlewares/logger-middleware.ts](/getway/src/middlewares/logger-middleware.ts) | TypeScript | 27 | 0 | 3 | 30 |
| [getway/src/middlewares/morgan-middleware.ts](/getway/src/middlewares/morgan-middleware.ts) | TypeScript | 11 | 0 | 2 | 13 |
| [getway/src/routes/v1.routes.ts](/getway/src/routes/v1.routes.ts) | TypeScript | 23 | 0 | 3 | 26 |
| [getway/src/server.ts](/getway/src/server.ts) | TypeScript | 24 | 0 | 5 | 29 |
| [getway/src/services.ts](/getway/src/services.ts) | TypeScript | 10 | 0 | 1 | 11 |
| [getway/src/services/proxy.service.ts](/getway/src/services/proxy.service.ts) | TypeScript | 67 | 0 | 7 | 74 |
| [getway/src/utils/instanceError.ts](/getway/src/utils/instanceError.ts) | TypeScript | 12 | 0 | 1 | 13 |
| [getway/tsconfig.json](/getway/tsconfig.json) | JSON with Comments | 14 | 0 | 1 | 15 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)