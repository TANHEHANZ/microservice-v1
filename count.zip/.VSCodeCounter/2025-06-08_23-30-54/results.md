# Summary

Date : 2025-06-08 23:30:54

Directory c:\\Users\\mi\\Desktop\\PROYECTOS\\REFACTOR\\getway

Total : 22 files,  449 codes, 0 comments, 61 blanks, all 510 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| TypeScript | 18 | 371 | 0 | 49 | 420 |
| JSON | 2 | 45 | 0 | 2 | 47 |
| Docker | 1 | 19 | 0 | 9 | 28 |
| JSON with Comments | 1 | 14 | 0 | 1 | 15 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 22 | 449 | 0 | 61 | 510 |
| . (Files) | 4 | 78 | 0 | 12 | 90 |
| src | 18 | 371 | 0 | 49 | 420 |
| src (Files) | 3 | 42 | 0 | 9 | 51 |
| src\\config | 3 | 105 | 0 | 9 | 114 |
| src\\enum | 2 | 10 | 0 | 2 | 12 |
| src\\errors | 4 | 26 | 0 | 8 | 34 |
| src\\middlewares | 3 | 86 | 0 | 10 | 96 |
| src\\routes | 1 | 23 | 0 | 3 | 26 |
| src\\services | 1 | 67 | 0 | 7 | 74 |
| src\\utils | 1 | 12 | 0 | 1 | 13 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)